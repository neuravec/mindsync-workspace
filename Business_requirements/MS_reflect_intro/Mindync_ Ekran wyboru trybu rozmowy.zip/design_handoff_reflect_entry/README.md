# Handoff: Reflect entry — mode choice (voice / text) + "start with" sheet

## Overview
Entering **Reflect** currently drops the user straight into the text chat, with a small phone icon in the corner that nobody notices — analytics show almost zero voice conversations. This design replaces that with an explicit two-step entry:

1. **Mode choice screen** — full-screen 50/50 split: voice (top, dark) vs text (bottom, light). Voice is half the screen, not an icon.
2. **"What do you want to start with?" sheet** — a light bottom sheet that slides over the mode screen after the mode is picked: three threads from the user's last sessions, or **Start fresh · no prompts**.

Picking a thread or Start fresh routes into the existing voice agent screen or the existing text chat screen, with the chosen topic seeded.

## About the Design Files
The files in this bundle are **design references written in HTML** — prototypes of the intended look and behaviour. They are **not production code to copy**. Recreate the screens in the target codebase (React Native / Expo / SwiftUI / whatever Mindsync ships) using its existing components, navigation and theming. If a pattern already exists in the app (sheet component, card, badge, primary button), use that pattern and match the values below.

`ReflectMode.dc.html` (voice session + text chat) is a **stand-in for screens that already exist in the app** — do not rebuild them from this file; just navigate to the real ones.

## Fidelity
**High fidelity** for the two new screens (mode choice + sheet): colors, type, spacing, radii and interactions below are final. The destination screens (voice session, text chat) are low-fidelity stand-ins.

## Screens / Views

### 1. Mode choice (`ReflectEntry`)
**Purpose:** choose how to talk to the AI. Shown when Reflect is opened **and there is no active conversation** (new session). If a conversation is active, skip straight into it.

**Layout** — full screen (no bottom tab bar on this screen), `flex-direction: column`, two equal halves (`flex: 1` each).

- **Back control**: absolutely positioned, top `56px` (i.e. just under the status bar), left `18px`; 38×38, `border-radius: 19px`, background `rgba(255,255,255,.14)`, hover `rgba(255,255,255,.24)`; chevron-left stroke `#FFFFFF`, stroke-width 2.4. Pops back to where Reflect was opened from.
- **Status bar**: light content (white glyphs) — the top half is dark.

**Top half — Voice (tappable, whole half)**
- Background: `radial-gradient(120% 90% at 50% 30%, #1B584B 0%, #0F3D33 70%)`
- Decorative waveform: 7 bars, absolutely positioned, `top: 120px`, horizontally centered, `gap: 6px`, bars `width: 6px`, `border-radius: 3px`, heights `28, 56, 88, 62, 34, 70, 24` px, colors `rgba(166,232,216,.55 / .75 / 1 (#A6E8D8) / .75 / .55 / .65 / .45)`. Static in the mock; a low-amplitude idle animation is welcome.
- Text block bottom-aligned, padding `0 28px 34px`:
  - Kicker "VOICE" — 12px / 700 / `letter-spacing: .1em` / uppercase / `#A6E8D8`
  - Title "Say it out loud" — 32px / 700 / line-height 1.1 / `letter-spacing: -.02em` / `#FFFFFF`
  - Body "Hands-free, eyes closed if you want. The AI speaks back." — 15px / 400 / line-height 1.5 / `rgba(255,255,255,.72)` / `max-width: 290px`

**Bottom half — Text (tappable, whole half)**
- Background: `linear-gradient(180deg, #F4FBF9 0%, #E2F2EE 100%)`
- Text block top-aligned, padding `34px 28px 0`:
  - Kicker "TEXT" — 12px / 700 / `.1em` / uppercase / `rgba(18,62,54,.5)`
  - Title "Write it down" — 32px / 700 / 1.1 / `-.02em` / `#123E36`
  - Body "Type at your own pace. Nothing gets read aloud." — 15px / `rgba(18,62,54,.62)` / `max-width: 290px`
- Decorative chat bubbles: absolutely positioned `bottom: 96px; left: 28px; right: 28px`, column, `gap: 8px`; bubble 1 — height 34, width 78%, `background: #FFF`, `border: 1px solid rgba(15,61,51,.07)`, `border-radius: 12px 12px 12px 4px`; bubble 2 — height 34, width 56%, right-aligned, `background: #0F3D33`, `border-radius: 12px 12px 4px 12px`.

Tapping either half sets the mode and opens the sheet. No separate confirm button.

### 2. "Start with" sheet (over the mode screen)
**Purpose:** choose the topic — a thread from recent therapy context, or a blank start — without leaving the mode screen.

**Scrim**: `rgba(8,36,30,.5)` over the full screen, fades in `180ms ease-out`. Tapping the scrim dismisses the sheet and returns to the mode choice (mode is NOT committed until the user starts).

**Sheet**: bottom-anchored, `background: #F7FCFB`, `border-radius: 30px 30px 0 0`, padding `12px 24px 34px`, `box-shadow: 0 -18px 44px rgba(8,36,30,.3)`. Slides up `260ms cubic-bezier(.2,.8,.2,1)`. Height is content-driven (≈554px of an 874px screen with 3 threads). Should be swipe-to-dismiss and (if the app's sheet primitive supports it) non-modal/detented.

- **Grabber**: 42×5, `border-radius: 3px`, `rgba(18,62,54,.18)`, centered, `margin-bottom: 18px`.
- **Mode pill**: `background: #0F3D33`, `border-radius: 999px`, padding `7px 13px`, `gap: 7px`; icon (mic for voice, bubble for text) in `#A6E8D8`; label "VOICE"/"TEXT" 12.5px / 700 / `.04em` / `#FFFFFF`.
- **Switch link**: "Switch to text" / "Switch to voice" — 13px / 600 / `rgba(18,62,54,.55)`, underlined with `text-underline-offset: 3px`, hover `#0F3D33`. Swaps mode in place, sheet stays open.
- **Title**: "What do you want to start with?" — 25px / 700 / line-height 1.16 / `-.02em` / `#123E36`, `margin-top: 16px`.
- **Subtitle**: "Pick up a thread from your last sessions — or just begin." — 14.5px / 1.5 / `rgba(18,62,54,.6)`, `margin-top: 8px`.
- **Thread rows** (`margin-top: 20px`, column, `gap: 8px`) — up to 3, newest/most relevant first:
  - Row: `background: #FFFFFF`, `border: 1px solid rgba(15,61,51,.08)`, `border-radius: 16px`, padding `14px 16px`, flex row, `gap: 12px`; hover/press `border-color: rgba(15,61,51,.24)` (`transition: border-color 140ms ease`).
  - Title: 15px / 600 / line-height 1.35 / `#123E36`, `text-wrap: pretty`, 2 lines max.
  - Source badge (`margin-top: 6px`, `gap: 7px`): `border-radius: 6px`, padding `3px 7px`, 11px / 700 / `.03em`.
    - `PREP` — bg `#EDE4F7`, text `#4A3A66`
    - `RECORDING` — bg `#CFE9E2`, text `#0F3D33`
    - `OPEN THREAD` — bg `#FBEEDC`, text `#6B4A18`
  - Meta next to badge (date or "2 messages") — 12px / `rgba(18,62,54,.5)`.
  - Trailing chevron-right, 8×14, stroke `rgba(18,62,54,.32)`, width 2.
- **Primary button**: "Start fresh" + secondary word "no prompts" — height 56, `border-radius: 28px`, `background: #0F3D33` (hover `#1B584B`), label 16px / 600 / `#FFFFFF`, hint 14px / 500 / `rgba(255,255,255,.6)`, `gap: 9px`, `margin-top: 14px`.

**Empty state (first session / no history):** hide the thread list and the subtitle's first clause; the sheet becomes pill + title ("What do you want to start with?") + Start fresh button. Worth designing copy for before shipping.

### 3. Destinations (existing screens — stand-ins in the mock)
- **Voice** → voice agent session (mic live, AI speaks back). Mock shows: dark `#0F3D33` background, 118px circle `linear-gradient(160deg,#A6E8D8,#6FCBB6)` with 4 animated bars, pulsing rings, caption, End button.
- **Text** → existing Reflect chat thread, with the picked topic seeded as context.

## Interactions & Behavior
| Trigger | Result |
| --- | --- |
| Open Reflect, no active conversation | Mode choice screen |
| Open Reflect, active conversation | Straight into that conversation (screen skipped) |
| Tap voice half / text half | `mode = voice|text`, sheet slides up (260ms) |
| Tap "Switch to …" | Mode toggles, sheet stays open, no re-animation |
| Tap thread row | Navigate to `mode` screen with `threadId` as context |
| Tap "Start fresh" | Navigate to `mode` screen with no seed |
| Tap scrim / swipe down | Sheet dismisses, back to mode choice, nothing committed |
| Back chevron (mode screen) | Leaves Reflect |
| Back from session screen | Returns to mode choice (fresh session) |

Notes: no auto-selection or remembered default — the whole point is that the choice is visible. Request mic permission only after voice is actually started (thread tap / Start fresh), not on mode pick. Voice half should have an accessibility label naming it as a button; both halves are ≥400px tall, far above the 44px minimum.

## State Management
```
view: 'base' | 'sheet' | 'voice' | 'text'   // 'base' stays mounted under the sheet
mode: 'voice' | 'text'                      // committed only when a session starts
threads: Array<{ id, title, source: 'prep'|'recording'|'open_thread', meta }>  // max 3, from therapy context
```
Data needed: the 3 most relevant recent threads (prep cards, recordings, open Reflect threads) with title + source + date/length. If the call is slow, show the sheet with the Start fresh button immediately and skeleton the rows.

## Design Tokens
Colors
- Deep green (primary / dark surface): `#0F3D33`; hover/lighter `#1B584B`
- Ink: `#123E36`; muted `rgba(18,62,54,.62)`; subtle `rgba(18,62,54,.5)`; hairline `rgba(15,61,51,.08)`
- Mint accent: `#A6E8D8`; mint fill `#CFE9E2`; mint tint `#DDF0EB`
- Light surfaces: `#FFFFFF`, sheet `#F7FCFB`, screen gradient `#F4FBF9 → #E2F2EE`
- Badge accents: lavender `#EDE4F7`/`#4A3A66`, cream `#FBEEDC`/`#6B4A18`
- Scrim: `rgba(8,36,30,.5)`

Typography — **Figtree** (400/500/600/700/800) in the mock; substitute the app's existing geometric sans. Scale used: 32 / 25 / 21 / 16 / 15 / 14.5 / 13 / 12.5 / 12 / 11.5 / 11 px. Titles `letter-spacing: -.02em`, kickers/badges `+.03….1em` uppercase.

Spacing: 6 / 8 / 10 / 12 / 14 / 16 / 18 / 20 / 24 / 28 / 34 px. Radii: 3 (grabber) / 6 (badge) / 16 (row) / 18 / 19 / 28 (button, pill-height) / 30 (sheet) / 999 (pill). Shadows: sheet `0 -18px 44px rgba(8,36,30,.3)`; card `0 2px 10px rgba(15,61,51,.05)`. Motion: sheet `260ms cubic-bezier(.2,.8,.2,1)`, scrim `180ms ease-out`, card/border hover `140ms ease`.

## Assets
- No image assets. All icons are inline SVG (mic, chat bubble, chevrons, play/pause) — replace with the app's icon set.
- The orca mascot (Pippi) is **not** used on this screen. Earlier explorations placed it here; it was dropped to keep the choice the only thing on screen.
- Device bezel/status bar in the mocks is a prototyping frame only.

## Files
- `Reflect Entry.dc.html` — final design: mode choice + sheet + routing (this is the spec)
- `ReflectMode.dc.html` — low-fi stand-ins for the voice session and text chat destinations
- `Reflect Mode Choice.dc.html` — the exploration board (all earlier options, for context)
- `ios-frame.jsx`, `support.js` — prototype runtime/bezel, not part of the design

Open any `.dc.html` in a browser to click through the flow. Polish copy is built in: set the `lang` prop to `pl` (`threadCount` and `showSourceBadges` are also adjustable).
